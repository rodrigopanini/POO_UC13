</main>

<?php if ($page != 'login') : ?>
<footer class="bg-light text-center py-3 border-top">
    <p>&copy; <?php echo date("Y"); ?> - UC 13 - Técnico em Informática</p>
</footer>
<?php endif; ?>

<!-- JS Bootstrap -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

</body>

</html>